﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        double numero1, numero2, numero3;
        public Form2()
        {
            InitializeComponent();
        }

        private void Txtn1_Validated(object sender, EventArgs e)
        {
          if  (!Double.TryParse(txtn1.Text, out numero1))
                MessageBox.Show("numero invalido");
        }

        private void Btnmult_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtn1.Text, out numero1) &&
               Double.TryParse(txtn2.Text, out numero2))
            {
                numero3 = numero1 * numero2;
                txtn3.Text = numero3.ToString();
            }
            else
                MessageBox.Show("numero invalido");
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtn1.Text, out numero1) &&
               Double.TryParse(txtn2.Text, out numero2) && numero2 != 0)
            {
                numero3 = numero1 / numero2;
                txtn3.Text = numero3.ToString();
            }
            else
                MessageBox.Show("numero invalido");
        }

        private void Txtn3_Validated(object sender, EventArgs e)
        {

        }

        private void Txtn2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtn1.Text, out numero1))
                MessageBox.Show("numero invalido");
        }

        private void Btnsum_Click_1(object sender, EventArgs e)
        {
            if (Double.TryParse(txtn1.Text, out numero1) &&
                           Double.TryParse(txtn2.Text, out numero2))
            {
                numero3 = numero1 + numero2;
                txtn3.Text = numero3.ToString();
            }
            else
                MessageBox.Show("numero invalido");
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btnlimp_Click(object sender, EventArgs e)
        {
            txtn1.Clear();
            txtn2.Clear();
            txtn3.Clear();


        }

        private void Btnsub_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtn1.Text, out numero1) &&
                Double.TryParse(txtn2.Text, out numero2))
            {
                numero3 = numero1 - numero2;
                txtn3.Text = numero3.ToString();
            }
            else
                MessageBox.Show("numero invalido");
        }
    

     
 

        private void Btnsum_Click(object sender, EventArgs e)
        {
           
        }
    }
}
