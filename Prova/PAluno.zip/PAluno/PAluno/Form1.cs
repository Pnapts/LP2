﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[10, 3];
            double media = 0;
            double mediaG = 0;
            string stringona;

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    stringona = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(stringona, out Notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida \nDigite Novamente");
                        i--;
                    }
                    else if (!(Notas[i, j] >= 0) && (Notas[i, j] <= 10))
                    {
                        MessageBox.Show("Nota Inválida \nDigite Novamente");
                        j--;
                    }
                    else
                    {
                        media = (Notas[i, 0] + Notas[i, 1] + Notas[i, 2]) / 3;
                        mediaG += media;

                    }

                }
                lstMedia.Items.Add($"O Aluno:{i + 1} Nota Professor {1} : {Notas[i, 0]} Nota Professor {2} : {Notas[i, 1]} Nota Professor {3} : {Notas[i, 2]} Média {media}");
            }
            lstMedia.Items.Add($"Média Geral Alunos: {mediaG/10}");
        }
       
    }
}



    

